Audio Muffler plugin by NovaSilisko

v1.0

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

A simple plugin that modifies your game audio - as the atmosphere around you thins, sound becomes more and more muffled until it's just a deep bass rumble.

Can be turned on and off in muffler.cfg. Just change the "enabled" field to false. Also in the cfg is a "debug" parameter, which will spew a bunch of information about the muffling process as it happens (normally left off so as to avoid console clutter)

Future developments: Configurable muffling amounts, in-game configuration window (maybe)

Known issues: Muffles music. Nothing I can do about this, Unity's audio system is kinda inflexible unfortunately!

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

Please don't redistribute without my permission. I will try to reply as quickly as possible to any requests, but if I can't be contacted and/or am dead, please wait 2-3 weeks, then you can re-release/modify/fix at your leisure. However, if I should return from an absence or be raised from the dead and not approve of this re-release, I reserve the right to beat you up and/or request its removal.