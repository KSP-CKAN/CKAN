To install NanoKube, copy the Contents of NanoKube_Base/GameData into your GameData folder
This is all you need to get started.


If you have Remote Technologies Group's RemoteTech mod installed, also copy the contents of NanoKube_RemoteTech_Upgrade/GameData to you GameData folder.
This should make the NanoKube probes and antennas RemoteTech-Compatible.




NanoKube assembly turorial can be found at imgur.com/a/IvFBo

The science experiments only run while in space.