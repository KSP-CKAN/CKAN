KDEX - Kerbal Dust Experiment by masTerTorch

Install:

1. Unzip
2. Copy the folder "masTerTorch" into your "KSP/GameData" folder.
3. Play
4. KDEX is part of the "Space Exploration" tech node.

Visit the forums for more information.

hf & gl