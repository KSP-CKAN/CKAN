Put the 'ImprovedChaseCamera' folder in your GameData folder.

To toggle, press 'tab' (configurable) while in Chase Camera mode or Free Camera mode.
It is active by default (also configurable).

The camera will follow your velocity vector.
While in Chase mode, the camera locks with roll.
While in Free mode, the camera stays level.

(Experimental) Mouse control:
Press right-alt while ICC is active to control plane with your mouse.
Plane will pitch/yaw towards your mouse (you still need to roll with keyboard).