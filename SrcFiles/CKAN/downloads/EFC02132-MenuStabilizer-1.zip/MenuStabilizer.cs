using System;
using UnityEngine;

using System.Collections.Generic;

namespace MenuStabilizer
{
    [KSPAddon(KSPAddon.Startup.Flight, false)]
    public class Loader : MonoBehaviour
    {
        public Loader()
        {
            Update();
        }

        public void Update()
        {
            var controller = UIPartActionController.Instance;
            if (!controller)
                return;

            var prefab = controller.windowPrefab;
            if (!prefab)
                return;

            // Pre-attach the stabilizer to the menu window template
            if (!prefab.GetComponent<WindowStabilizer>())
                prefab.gameObject.AddComponent<WindowStabilizer>();

            Destroy(this);
        }
    }

    // This is instantiated for every part menu window and locks it position when moused over
    public class WindowStabilizer : MonoBehaviour
    {
        private UIPartActionWindow window;
        private EZScreenPlacement window_pos;

        private int child_count = 0;
        private List<UIPartActionItem> items;
        private bool interactive = false;

        private bool frozen = false;
        private Vector3 frozen_pos;

        protected void Awake()
        {
            window = gameObject.GetComponent<UIPartActionWindow>();
            window_pos = gameObject.GetComponent<EZScreenPlacement>();
        }

        private void EnumerateItems()
        {
            child_count = transform.childCount;
            items = new List<UIPartActionItem>();

            for (int i = 0; i < child_count; i++)
            {
                var child = transform.GetChild(i).GetComponent<UIPartActionItem>();
                if (child != null)
                    items.Add(child);
            }
        }

        private bool IsInteractive(List<UIPartActionItem> items)
        {
            foreach (var item in items)
            {
                if (item is UIPartActionLabel || item is UIPartActionProgressBar)
                    continue;

                return true;
            }

            return false;
        }

        private Rect GetWindowRect()
        {
            var title_box = window.titleBar.collider as BoxCollider;
            Vector3 row_start = window.rowRootTransform.localPosition;

            float width = (title_box != null) ? title_box.size.x : row_start.x + 200;
            float height = -row_start.y + window.rowHeight * items.Count;

            return new Rect(window_pos.screenPos.x, window_pos.screenPos.y-height, width, height);
        }

        public void LateUpdate()
        {
            // Check if the window is valid or changed size
            if (!window.isValid)
            {
                frozen = false;
                items = null;
                return;
            }

            if (items == null || transform.childCount != child_count)
            {
                EnumerateItems();

                interactive = IsInteractive(items);
            }

            // Unfreeze all in map view or when manipulating the camera
            if (!interactive || MapView.MapIsEnabled ||
                Input.GetMouseButton(1) || Input.GetMouseButton(2) ||
                GameSettings.AXIS_MOUSEWHEEL.GetAxis() != 0f ||
                GameSettings.ZOOM_IN.GetKey() || GameSettings.ZOOM_OUT.GetKey() ||
                GameSettings.CAMERA_ORBIT_LEFT.GetKey() || GameSettings.CAMERA_ORBIT_RIGHT.GetKey() ||
                GameSettings.CAMERA_ORBIT_UP.GetKey() || GameSettings.CAMERA_ORBIT_DOWN.GetKey())
            {
                frozen = false;
                return;
            }

            // Restore last position if frozen
            if (frozen)
            {
                frozen_pos.z = window.zOffset;

                window_pos.screenPos = frozen_pos;
                window_pos.UpdateCamera();
            }

            // Save position if moused over
            frozen = GetWindowRect().Contains(Input.mousePosition);

            if (frozen)
                frozen_pos = window_pos.screenPos;
        }
    }
}
