﻿using System;
using UnityEngine;
using KSP.IO;
using FinalFrontierAdapter;

namespace Nereid
{
   namespace FinalFrontier
   {

      //[KSPAddon(KSPAddon.Startup.Instantly, true)]
      [KSPAddon(KSPAddon.Startup.EveryScene, false)]
      public class FinalFrontier : MonoBehaviour
      {
         private static long wokenupCount = 0;

         private static EventObserver observer = new EventObserver();

         public static readonly String RESOURCE_PATH =  "Nereid/FinalFrontier/Resource/";

         public static readonly Configuration configuration = new Configuration();

         public static readonly FARAdapter farAdapter = new FARAdapter();

         private volatile IButton toolbarButton;
         private volatile HallOfFameBrowser browser;

         private volatile ApplicationLauncherButton stockToolbarButton = null;

         // just to make sure that all pool instances exists
         private ActivityPool activities = ActivityPool.Instance();
         private RibbonPool ribbons = RibbonPool.Instance();
         private ActionPool actions = ActionPool.Instance();

         private volatile bool keyAltPressed = false;
         private volatile bool keyCtrlPressed = false;

         private volatile bool destroyed = false;

         public FinalFrontier()
         {
            Log.Info("new instance of Final Frontier");
         }

         public void Awake()
         {
            Log.Info("awakening Final Frontier");
            wokenupCount++;
            // first awake?
            if (IsFirstAwake())
            {
               Log.Info("first awakening");
               configuration.Load();
               Log.SetLevel(configuration.GetLogLevel());
               //
               // plugin adapters
               farAdapter.Plugin();
               //
               // log installed plugins
               Log.Info("FAR installed: " + farAdapter.IsInstalled());
            }
            Log.Info("log level is " + configuration.GetLogLevel());

         }


         public void Start()
         {
            Log.Info("starting FinalFrontier");
            if (!configuration.UseStockToolbar())
            {
               Log.Info("stock toolbar button disabled");
               AddToolbarButtons();
            }
            else
            {
               Log.Info("stock toolbar button enabled");
               CreateStockToolbarButton();
            }
         }

         private void CreateStockToolbarButton()
         {
            if (ApplicationLauncher.Instance != null && ApplicationLauncher.Ready)
            {
               Log.Detail("ApplicationLauncher is ready");
               OnGUIAppLauncherReady();
            }
            else
            {
               Log.Detail("ApplicationLauncher is not ready");
               GameEvents.onGUIApplicationLauncherReady.Add(OnGUIAppLauncherReady);
            }
         }


         private void OnGUIAppLauncherReady()
         {
            if (destroyed) return;
             if(configuration.UseStockToolbar())
             {
                Log.Info("using stock toolbar button");
                if (ApplicationLauncher.Ready && stockToolbarButton==null)
                {
                   Log.Info("creating stock toolbar button");
                   stockToolbarButton = ApplicationLauncher.Instance.AddModApplication(
                   OnAppLaunchToggleOn,
                   OnAppLaunchToggleOff,
                   DummyVoid,
                   DummyVoid,
                   DummyVoid,
                   DummyVoid,
                   ApplicationLauncher.AppScenes.FLIGHT | ApplicationLauncher.AppScenes.SPACECENTER | ApplicationLauncher.AppScenes.MAPVIEW | ApplicationLauncher.AppScenes.SPH | ApplicationLauncher.AppScenes.VAB | ApplicationLauncher.AppScenes.TRACKSTATION,
                   (Texture)GameDatabase.Instance.GetTexture(RESOURCE_PATH + "ToolbarIcon", false));
                   if(stockToolbarButton==null) Log.Warning("no stock toolbar button registered");
                }
             }
         }

         void OnAppLaunchToggleOn()
         {
            createBrowserOnce();
            if(browser!=null)
            {
               browser.SetVisible(true);
            }
         }

         void OnAppLaunchToggleOff()
         {
            if (browser != null)
            {
               browser.SetVisible(false);
            }
         }

         private void DummyVoid() { }

         private bool IsFirstAwake()
         {
            return wokenupCount == 1;
         }



         public void Update()
         {
            //
            if (Input.GetKeyDown(KeyCode.LeftAlt)) keyAltPressed = true;
            if (Input.GetKeyUp(KeyCode.LeftAlt)) keyAltPressed = false;
            if (Input.GetKeyDown(KeyCode.LeftControl)) keyCtrlPressed = true;
            if (Input.GetKeyUp(KeyCode.LeftControl)) keyCtrlPressed = false;
            if (configuration.IsHotkeyEnabled() && keyAltPressed && Input.GetKeyDown(KeyCode.F))
            {
               Log.Info("hotkey ALT-F detected");
               
               switch (HighLogic.LoadedScene)
               {
                  case GameScenes.EDITOR:
                  case GameScenes.FLIGHT:
                  case GameScenes.SPACECENTER:
                  case GameScenes.TRACKSTATION:
                     if (!keyCtrlPressed)
                     {
                        Log.Info("hotkey hall of fame browser");
                        createBrowserOnce();
                        browser.SetVisible(!browser.IsVisible());
                     }
                     else
                     {
                        Log.Info("hotkey reset window positions");
                        PositionableWindow.ResetAllWindowPositions();
                     }
                     break;
                  default:
                     Log.Info("cant open/close hall of fame in game scene " + HighLogic.LoadedScene);
                     break;
               }
            }

            if (observer != null)
            {
               observer.Update();
            }
         }

         private void AddToolbarButtons()
         {
            Log.Detail("adding toolbar buttons");
            String iconOn = RESOURCE_PATH + "IconOn_24";
            String iconOff = RESOURCE_PATH + "IconOff_24";
            toolbarButton = ToolbarManager.Instance.add("FinalFrontier", "button");
            if (toolbarButton != null)
            {
               toolbarButton.TexturePath = iconOff;
               toolbarButton.ToolTip = "Open Final Frontier";
               toolbarButton.OnClick += (e) =>
                   {
                      createBrowserOnce();
                      if (browser != null) browser.registerToolbarButton(toolbarButton, iconOn, iconOff);
                      toggleBrowserVisibility();
                   };

               toolbarButton.Visibility = new GameScenesVisibility(GameScenes.EDITOR, GameScenes.FLIGHT, GameScenes.SPACECENTER, GameScenes.TRACKSTATION);
            }
            else
            {
               Log.Error("toolbar button was null");
            }
            Log.Detail("toolbar buttons added");
         }

         private void toggleBrowserVisibility()
         {
            browser.SetVisible(!browser.IsVisible());
         }

         private void createBrowserOnce()
         {
            if (browser == null)
            {
               Log.Info("creating new hall of fame browser");
               browser = new HallOfFameBrowser();
               browser.CallOnWindowClose(OnBrowserClose);
            }
         }

         public void OnBrowserClose()
         {
            if (stockToolbarButton != null)
            {
               stockToolbarButton.toggleButton.Value = false;
            }            
         }

         internal void OnDestroy()
         {
            Log.Info("destroying Final Frontier");
            destroyed = true;
            GameEvents.onGUIApplicationLauncherReady.Remove(OnGUIAppLauncherReady);
            configuration.Save();
            if(toolbarButton!=null)
            {
               Log.Detail("removing toolbar button");
               toolbarButton.Destroy();
            }
            if (stockToolbarButton != null)
            {
               Log.Detail("removing stock toolbar button");
               ApplicationLauncher.Instance.RemoveModApplication(stockToolbarButton);
            }
            stockToolbarButton = null;
         }

      }
   }
}
