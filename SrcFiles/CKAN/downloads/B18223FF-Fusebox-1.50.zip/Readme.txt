Fusebox v0.95

Delete any older version you may have installed.

Copy the contents of GameData with yours and that's it. If you already have toolbar installed skip the 000_Toolbar.
Click the battery icon to open with toolbar.
If not using toolbar click the name tab for minimise. The 2nd click gets you back to normal.

Adds the ability to halt warp if your charge level goes under a set threshold. Defaults to 30%.

Thanks to hakan for the CKAN config and pamidur for the RPM addin code.

Thanks go to KSPClock for inadvertantly providing a lovely example of a minimal functional plugin, MechJeb and FAR for 
c# examples and GUI 'how does that work'. landeTLS for toolbar icons and toadicus for his ToolbarButtonWrapper. And the
author of http://wiki.kerbalspaceprogram.com/wiki/Orbit_darkness_time for the orbital darkness maths.

License GPLv2