﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VanguardTechnologies
{
    class ModuleKrImAFloat : PartModule
    {
        [KSPField(guiActive = true, guiName = "This is me", isPersistant = false)]
        float me = -1;
    }
}
