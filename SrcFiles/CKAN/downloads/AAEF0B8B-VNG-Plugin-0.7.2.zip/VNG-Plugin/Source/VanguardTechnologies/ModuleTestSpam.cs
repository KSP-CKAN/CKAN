﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/// <summary>
/// Shows when which override of PartModule is called
/// </summary>
class ModuleKrTestSpam : PartModule
{
    public override void OnActive()
    {
        print("OnActive");
    }
    public override void OnAwake()
    {
        print("OnAwake");
    }
    public override void OnInactive()
    {
        print("OnInactive");
    }
    public override void OnLoad(ConfigNode node)
    {
        print("OnLoad");
    }
    public override void OnFixedUpdate()
    {
        print("OnFixedUpdate");
    }
    public override void OnUpdate()
    {
        print("OnUpdate");
    }
    public override void OnSave(ConfigNode node)
    {
        print("OnSave");
    }
    public override void OnStart(StartState state)
    {
        print("OnStart:" + state);
    }
}
