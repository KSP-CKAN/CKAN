﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

public class ModuleKrEjectPilot : PartModule
{
    [KSPField]
    public float ejectionForce = 10000;
    [KSPField(guiActive = true, guiName = "Uses left", isPersistant = true)]
    public float maxUses = 3;

    private ProtoCrewMember kerbal;
    private bool ejecting;

    [KSPAction("Eject Crew", KSPActionGroup.Abort)]
    public void Eject(KSPActionParam param)
    {
        ejecting = param.type == KSPActionType.Activate;
        part.SendEvent("OnDeboardSeat");
    }

    public void Update()
    {
        if (!HighLogic.LoadedSceneIsFlight)
            return;
        //if (vessel.GetVesselCrew().Count == 0)
        //    ejecting = false;
        if (ejecting)
        {
            foreach (Part p in vessel.parts)
            {
                if (p.protoModuleCrew.Count == 0)
                {
                    print("nobody inside");
                    continue;
                }
                kerbal = p.protoModuleCrew[0];
                if (kerbal == null) //Probably not necessary
                    continue;
                print(FlightEVA.fetch.spawnEVA(kerbal, p, p.airlock));
                maxUses--;
                print(maxUses);
                for (int i = FlightGlobals.Vessels.Count - 1; i >= 0; i--)
                    if (kerbal.name == FlightGlobals.Vessels[i].vesselName)
                    {
                        print("adding parachute");
                        FlightGlobals.Vessels[i].rootPart.AddModule("ModuleKrKerbalParachute");
                        FlightGlobals.Vessels[i].rootPart.Modules["ModuleKrKerbalParachute"].OnStart(StartState.Flying);
                        print("adding force");
                        FlightGlobals.Vessels[i].rootPart.Rigidbody.AddForce(FlightGlobals.Vessels[i].rootPart.transform.up * ejectionForce);
                        return;
                    }
                if (maxUses == 0)
                {
                    part.explode();
                    return;
                }
            }
            ejecting = false;
        }
    }

    public override string GetInfo()
    {
        string desc = "Has ejection capability";
        if (maxUses > 0) desc += " for " + maxUses + " crew members";
        return desc;
    }
}