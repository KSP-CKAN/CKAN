﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace VanguardTechnologies
{
    public class ModuleKrPartInfo : PartModule
    {
        bool alreadyPrintedInternal = false;
        public override void OnStart(PartModule.StartState state)
        {
            print("--- PART INFO ---");

            print("fxgroups:");

            foreach (FXGroup f in part.fxGroups)
                print(f.name);

            print("Attach nodes:");

            foreach (AttachNode n in part.attachNodes)
                print(n.id);
            print("--- MODEL INFO ---");

            print("Animations:");
            foreach (Animation a in part.FindModelAnimators())
            {

                print("* " + a.name);

                foreach (AnimationState s in a)
                    print("** " + s.name);
            }

            print("Transforms:");

            printTransforms(part.transform);


            print("--- END OF MODEL INFO ---");
        }

        public override void OnUpdate()
        {
            if (part.internalModel != null && !alreadyPrintedInternal)
            {
                print("--- INTERNAL INFO ---");
                print("Internal transforms:");

                printTransforms(part.internalModel.transform);
                alreadyPrintedInternal = true;
                print("--- END OF INTERNAL INFO ---");
            }
        }
        public static void printTransforms(Transform t, string prefix = "")
        {
            print(prefix + t.name);
            prefix += "*";
            for (int i = 0; i < t.childCount; i++)
                printTransforms(t.GetChild(i), prefix);
        }
    }
}
