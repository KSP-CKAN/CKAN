Kerbal Flight Data
========================================
A mod for Kerbal space program which displays 
essential information for piloting space planes 
under the Ferram-Aerospace-Research mod. It is 
meant as an minimalistic addition to the stock 
gui.

<img src="http://i.imgur.com/zxPixmT.jpg"/>


Acknowledgement
----------------------------------------
Thanks for
* the SteamGauge source by Trueborn for a nice reference for
how to get to various data,
* the API documentation project at https://github.com/Anatid/XML-Documentation-for-the-KSP-API
by Anatid and contributors,
* Blizzy's Toolbar

License
----------------------------------------
GNU General Public License Version 3, see <http://www.gnu.org/licenses/>