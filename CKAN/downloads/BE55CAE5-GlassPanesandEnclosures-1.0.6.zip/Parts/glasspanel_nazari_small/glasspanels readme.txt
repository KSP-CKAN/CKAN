by Nazari1382/2001kraft

Glass Box enclosure and glass panels mod

-gives your crew a place to rest on spacewalks and glass panels for building structures

=====

known issue: some parts may not show through the transparencies. Still a good view.