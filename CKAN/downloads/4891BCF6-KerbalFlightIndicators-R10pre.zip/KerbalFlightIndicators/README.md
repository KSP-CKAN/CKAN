Kerbal Flight Indicators
========================================

Draws various markers in your field of view. See http://forum.kerbalspaceprogram.com/threads/80277

<img src="http://i.imgur.com/UWlBv4y.jpg" title="Demonstration of the marker graphics"/>


Acknowledgement
----------------------------------------
There are some bits of code from Steam Gauges http://forum.kerbalspaceprogram.com/threads/40730
by Trueborn in here. Thanks for putting it under a not too restrictive
license.

License
----------------------------------------
http://creativecommons.org/licenses/by-nc-sa/3.0/