# RocketWatch
Fashion for your Rockets! Orbital Time-keeping for all your timekeeping needs!

Install this mod by placing the contents of its GameData folder in your KSP directory's GameData folder.

Just add this wristwatch to your rocket, and a window will be added upon launch that displays the real-world time just below the mission clock.

The watch can be attached in three ways: just below a Mk1 Command Pod, hiding the rounded bottom, surface attached to the vessel (just press "W" once to rotate it to the proper orientation), or between two standard Mk1 Parts.

Tweakscale is supported, but not required, and has not been tested.

The window is added using the MODULE "DigitalClock". If you would like to have the window without requiring the part be added, you may write a ModuleManager file to give "DigitalClock" to all the command pods. I will NOT be doing this myself, but will add a link to the file if someone does it and sends me the file.
