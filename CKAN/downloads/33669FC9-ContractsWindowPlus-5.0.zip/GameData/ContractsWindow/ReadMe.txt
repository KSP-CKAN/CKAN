Place the contents of the GameData folder in your KSP/GameData folder:

Kerbal Space Program/GameData/

Contracts Window will not function properly if not placed in the correct location.


*Blizzy78's Toolbar is supported, but not required