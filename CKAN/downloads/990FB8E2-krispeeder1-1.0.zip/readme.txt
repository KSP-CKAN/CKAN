Speeder-1 1.0

1. About

This is a single all-in-one surface vehicle for two kerbals, specifically designed to be used in conjunction with Kerbal Foundries's surface repulsors (at least three of them), on low gravity bodies but which also works quite well even on Kerbin. It can also orbit and de-orbit on its own on such low-grav bodies (tested on Minmus).

It includes a SAS system, embedded monopropellant tanks, an electric generator which is good enough to power the speeder alone and refill the battery when not moving, a front light, and two small very efficient thrusters.


2. Requirements

KSP 0.90, not tested on other releases but it may works.

Highly recommended:
Kerbal Foundries parts & plug-in: https://kerbalstuff.com/mod/58/Kerbal%20Foundries%20Wheels%20and%20Repulsors%20ALPHA

HyperEdit: http://forum.kerbalspaceprogram.com/threads/37756-0-90-HyperEdit-NEW-VERSION-Teleporter-Orbit-Planet-Editor-More
And/or Extra Planetary Launchpads: http://forum.kerbalspaceprogram.com/threads/59545-0-90-Extraplanetary-Launchpads-v5-1-2


3. how to install it (without CKAN) ?

Simply merge the provided GameData folder into your own, answer yes to any overwrite requests.


4. how to remove it (without CKAN) ?

Simply delete the folder Kerbice Group\landglider from you <KSP dir>\GameData directory. "Kerbice Group" folder can be deleted as well if no other of my mods is installed.


5. CKAN install/removal

See CKAN documentation for detailed informations on installation and removal of a mod.


6. usage

Build something with it, add wheels or repulsors or use it as the human NASA STS spaceship (center of mass here is very critical to avoid endless spinning). Launcher stage can also be build using strucutal pylon decouplers and two rockets on both sides.
Activate the on-board generator in order to provide some electric power, without the need of additional solar panels.
Launch and... cross your fingers.

Ladders are on both sides not visible, on the doors, to help going into or out the speeder.


7. Career mode

Price & cost have been set to quite dummy values, change it as you wish. Technology required have been set to match stock parts, you can also modify this if you believe it's not good enough.


8. know issues

[KSP] Sometimes/inconsistently, targa textures are not loaded properly by KSP, making the craft appear full white, reloading database (ALT-F12 debug menu from space center scene) can fix it, but it will mess all MM patches if there are any.


9. IVA

none.


10. alternate texture sizes

By default, the texture provided/installed is 1024x1024 (and 512x512 for lights).
There is a half-sized textures set in the "alternate textures size" folder of the archive (from Kerbal Stuff), in order to use them, copy the entire conent of this directory to <KSP_folder>\GameData\Kerbice Group\landglider (overwrite existing texture or rename it as you please).


11. template

If you want to make your own skin for the speeder, a template (you need The Gimp) is provided. Don't forget to export file as 'landglider-diffuse.tga' or it will not be used.


A. changelog

1.0  24/03/2015 first release


B. Contact

you can reach me directly on the KSP official forum as well as at JustinKerbice@hotmail.fr
If your question/concern is about how to use your paint program, convert a texture to a given format, how to create a rocket, how to crash Jeb's ship with style, or anything not DIRECTLY RELATED to this parts set, don't be surprised to wait forever for an answer.


C. license

This parts set and all its content, including this readme, is licensed under the whatever license 1.1, see included file for more details.