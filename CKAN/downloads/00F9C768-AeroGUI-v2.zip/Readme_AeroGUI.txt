Install: Drop the stuff in GameData into your GameData folder.

Use:
Press (mod) I (that's I as in India) during flight to show the GUI. Mod is Alt on PC, RShift on Linux, etc.

v2:
* Brought Mach/EAS/TV to top.
* Added setttings file (set key, toggle keybind uses modifier key, toggle WinterOwlMode).
* Added back thermal data window. Shows lots of useful stats, plus keeps a running count of convection.

v1:
Initial version. Shows aero stats.
******LICENSE********


Copyright (c) 2015 NathanKell


Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
