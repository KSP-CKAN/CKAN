HyperEdit was invented and is developed by khyperia, and distributed by Kerbaltek.

For comments, suggestions, questions and support, visit Kerbaltek's website.
http://www.Kerbaltek.com/hyperedit

Discuss HyperEdit in the KSP forum thread.
http://forum.kerbalspaceprogram.com/threads/37756

See the source code in the GitHub repository.
https://github.com/Ezriilc/HyperEdit

HyperEdit licensing is covered by the GPL found here:
https://www.gnu.org/copyleft/gpl.html
