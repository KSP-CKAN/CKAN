--------------------------
 Atmospheric Sound Enhancement
 Author:    pizzaoverhead
 Version:   2.2
 Released:  2015-05-05
 Licence:   GNU GPL v2
--------------------------

Description
-----------
Adds the effects of the density, temperature and relative speed of the atmosphere to craft sounds. When breaking the sound barrier, muffled sounds (or optionally no sounds) will be heard when the camera is outside of the shock cone. When passing through the cone, you can hear the shockwave. When leaving the atmosphere, the sound gradually fades to muffled (or optionally nothing) in vacuum. Internally, sounds can always be heard but are muffled.
The stock game's condensation effects are now visible when travelling at transonic velocities. The plasma re-entry effects are visible when travelling at hypersonic velocities, regardless of altitude.

Settings
--------
negativeSlopeWidthDeg
The angle (in degrees) behind the shock cone that the shock wave fades away over.

interiorVolumeScale
A multiplier for the volume inside the craft. 1 is 100%, 0.5 is 50%, 2 is 200%, 0 for silence.

interiorMaxFreq
How muffled the sounds heard inside the craft are. Sounds above this frequency aren't heard. It can be anywhere between 10 (a deep rumble that can only be heard with high-quality speakers) and 22000 Hz (not muffled at all). 0 disables internal sounds.

lowerMachThreshold
The Mach number at which the sonic boom starts to kick in.

upperMachThreshold
The Mach number at which the sonic boom finishes fading away.

maxDistortion
How distorted and crunchy the sound of the shock wave is. 0 is off (normal) and 1 is on fully (may cause crackling).

condensationEffectStrength
How thick the white graphical condensation effect is when passing through the sound barrier. 0 is off, 1 is very thick.

maxVacuumFreq
How muffled the sounds are when in a vacuum, similar to interiorMaxFreq. 0 disables all sounds, 22000 gives normal, unmuffled sounds.

maxSupersonicFreq
How muffled the sounds are when the camera is ahead of the supersonic shock wave., similar to interiorMaxFreq. 0 disables all sounds, 22000 gives normal, unmuffled sounds.


Licence
-------
Licence information is available here:
http://creativecommons.org/licenses/by-sa/3.0/


Installation
------------
Extract the zip to the root KSP folder, overwriting the GameData folder.


Uninstallation
--------------
Delete the AtmosphericSoundEnhancement folder from GameData.


Credits
-------
Thanks to velusip and szdarkhack for their major contributions to this mod. The plugin also makes reference to Deadly Reentry (http://forum.kerbalspaceprogram.com/threads/54954) for compatibility with its particle effects.

Version history
---------------
2.3 (2015-05-05)
- Fixed build for 1.0.

2.1.1 (2013-12-23)
- Rebuild for KSP 0.23.

2.1 (2013-11-27)
- Fixed incorrect or missing sound effects in some situations.
- Fixed some sounds being missed before first staging.
- Slight performance improvements.

2.0 (2013-11-21)
- Added a configuration file.
- Added the ability to choose between silence or muffled sound when supersonic or in a vacuum (muffled by default).
- Customised condensation and re-entry effects.
- Fixed issues with the Mach sounds not always being played at the correct angles.

1.1 (2013-11-03)
- Fixed sounds still playing while paused.
- Removed log message that was causing slowdown.

1.0 (2013-11-02)
- Initial release.