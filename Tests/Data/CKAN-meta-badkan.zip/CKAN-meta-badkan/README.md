Welcome to the CKAN metadata repository.

If you wish to add support for a new module,
[there's a guide for that](https://github.com/KSP-CKAN/CKAN/wiki/Adding-a-mod-to-the-CKAN).

If you're wondering what the CKAN is, start with
[this readme](https://github.com/KSP-CKAN/CKAN/blob/master/README.md).
