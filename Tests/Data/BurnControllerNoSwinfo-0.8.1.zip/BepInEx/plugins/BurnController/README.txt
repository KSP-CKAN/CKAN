# Burn Controller
Lets you set up engine burns.